const { initDB, prepare } = require('./db');

async function test() {
    try {
        await initDB();
        console.log('DB Initialized');

        const apps = await prepare('SELECT * FROM applications LIMIT 1').all();
        console.log('Apps:', apps);
        console.log('Type of apps:', typeof apps);
        console.log('Is array:', Array.isArray(apps));

        if (apps && typeof apps[Symbol.iterator] === 'function') {
            console.log('Apps is iterable');
        } else {
            console.log('Apps is NOT iterable');
        }

        process.exit(0);
    } catch (err) {
        console.error('Test error:', err);
        process.exit(1);
    }
}

test();
