const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { prepare } = require('../db');
const { JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

// Register
router.post('/register', async (req, res) => {
    try {
        const { identifier, password } = req.body;

        if (!identifier || !password) {
            return res.status(400).json({ error: 'Email or Username and password are required' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        const isEmail = identifier.includes('@');
        let email = isEmail ? identifier.toLowerCase() : null;
        let username = identifier;

        if (isEmail) {
            const existingEmail = await prepare('SELECT id FROM users WHERE email = ?').get(email);
            if (existingEmail) {
                return res.status(409).json({ error: 'Email already registered' });
            }
            // Use local part as initial username, ensure uniqueness
            username = email.split('@')[0];
            const existingUser = await prepare('SELECT id FROM users WHERE username = ?').get(username);
            if (existingUser) {
                username = `${username}_${Math.floor(Math.random() * 1000)}`;
            }
        } else {
            const existingUser = await prepare('SELECT id FROM users WHERE username = ?').get(username);
            if (existingUser) {
                return res.status(409).json({ error: 'Username already taken' });
            }
        }

        // First user becomes admin, rest are regular users
        const userCount = await prepare('SELECT COUNT(*) as c FROM users').get();
        const role = (userCount && userCount.c === 0) ? 'admin' : 'user';

        const passwordHash = await bcrypt.hash(password, 12);
        const result = await prepare('INSERT INTO users (email, username, password_hash, role) VALUES (?, ?, ?, ?)').run(email, username, passwordHash, role);

        const token = jwt.sign({ id: result.lastInsertRowid, email, username, role }, JWT_SECRET, { expiresIn: '7d' });

        res.status(201).json({ token, user: { id: result.lastInsertRowid, email, username, role } });
    } catch (err) {
        console.error('Register error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Login
router.post('/login', async (req, res) => {
    try {
        const { identifier, password } = req.body;

        if (!identifier || !password) {
            return res.status(400).json({ error: 'Email/Username and password are required' });
        }

        // Search by email OR username
        const user = await prepare('SELECT * FROM users WHERE email = ? OR username = ?').get(identifier, identifier);
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const valid = await bcrypt.compare(password, user.password_hash);
        if (!valid) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user.id, email: user.email, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

        res.json({ token, user: { id: user.id, email: user.email, username: user.username, role: user.role } });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
