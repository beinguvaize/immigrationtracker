const { initDB, prepare } = require('./db');

async function test() {
    try {
        await initDB();
        console.log('DB Initialized');
        const apps = await prepare('SELECT id, submission_date, status FROM applications LIMIT 5').all();
        console.log('Apps:', apps);
        console.log('Is array:', Array.isArray(apps));
        console.log('Type:', typeof apps);
        if (apps) {
            for (const app of apps) {
                console.log('App ID:', app.id);
            }
        }
        process.exit(0);
    } catch (err) {
        console.error('Test failed:', err);
        process.exit(1);
    }
}

test();
